# Portfolio App

A simple Portfolio application built with Node.js, Express, and MongoDB. This app allows users to register, log in, and create portfolio posts. Posts include a title, description, and an uploaded image. All posts are displayed for users to view.

---

## Features

- **User Authentication**: Users can register and log in.
- **CRUD Operations**:
    - Create: Users can create portfolio posts with an image upload.
    - Read: All users can view all portfolio posts.
    - Update/Delete: Users can manage their own posts.
- **API Integration**:
    - Displays the current weather in Astana.
    - Displays the latest news.

---

## Technologies Used

- **Backend**: Node.js, Express.js
- **Frontend**: HTML, CSS
- **Database**: MongoDB
- **File Upload**: Multer
- **API Integration**:
    - OpenWeatherMap API (for weather data)
    - NewsAPI (for latest news)

---

## Setup Instructions

### Prerequisites
- Node.js installed (v16 or higher)
- MongoDB installed and running locally or cloud-based (e.g., MongoDB Atlas)

### Installation
1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd portfolio-app
2. Install dependencies
npm install
3. Create a .env file in the root directory with the following:
PORT=3000
MONGO_URI=///
WEATHER_API_KEY=////
NEWS_API_KEY=///