const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const path = require('path');
const router = express.Router();


router.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/register.html'));
});


router.post('/register', async (req, res) => {
    try {
        const { email, password, firstName, lastName, age, role } = req.body;
        const user = new User({ email, password, firstName, lastName, age, role });
        await user.save();
        res.redirect('/auth/login');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error registering user');
    }
});


router.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/login.html'));
});


router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (user && (await bcrypt.compare(password, user.password))) {
        res.redirect('/posts/portfolio');
    } else {
        res.status(401).send('Invalid login credentials');
    }
});

module.exports = router;
