const express = require('express');
const multer = require('multer');
const Post = require('../models/Post');
const path = require('path');
const router = express.Router();


const storage = multer.diskStorage({
    destination: './public/uploads/',
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});
const upload = multer({ storage });

router.get('/portfolio', async (req, res) => {
    try {
        const posts = await Post.find().populate('author'); // Получение постов из базы
        res.sendFile(path.join(__dirname, '../views/portfolio.html')); // Возвращаем HTML страницу
    } catch (error) {
        console.error(error);
        res.status(500).send('Error loading portfolio');
    }
});

router.get('/portfolio/data', async (req, res) => {
    try {
        const posts = await Post.find().populate('author');
        res.json(posts); // Возвращаем JSON данные для JavaScript
    } catch (error) {
        console.error(error);
        res.status(500).send('Error fetching posts');
    }
});

router.post('/create', upload.single('image'), async (req, res) => {
    const { title, description, author } = req.body;
    const post = new Post({ title, description, image: `/uploads/${req.file.filename}`, author });
    await post.save();
    res.redirect('/posts/portfolio');
});

module.exports = router;
