const express = require('express');
const axios = require('axios');
const router = express.Router();


router.get('/weather', async (req, res) => {
    const weatherApiKey = 'e8ef13326df84fbeef66c9416f72a21c'; // Замените на ваш ключ
    const url = `https://api.openweathermap.org/data/2.5/weather?q=Astana&units=metric&appid=${weatherApiKey}`;

    try {
        const response = await axios.get(url);
        res.json(response.data);
    } catch (error) {
        console.error('Error fetching weather data:', error.message);
        res.status(500).send('Error fetching weather data');
    }
});


router.get('/exchange-rate', async (req, res) => {
    const apiKey = 'a6975e49442383c898123714'; // Замените на ваш ключ
    const url = `https://v6.exchangerate-api.com/v6/${apiKey}/latest/USD`;

    try {
        const response = await axios.get(url);
        const kztRate = response.data.conversion_rates.KZT;
        res.json({ rate: kztRate });
    } catch (error) {
        console.error('Error fetching exchange rate:', error.message);
        res.status(500).send('Error fetching exchange rate');
    }
});


module.exports = router;
